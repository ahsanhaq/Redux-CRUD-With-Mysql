﻿<!DOCTYPE html>
<html><head>
</head>
<body>
<div class="wrapper">
<?php echo $message_body?>
</div>
</body>
</html>
