<?php include_once('includes/header.php'); ?>

<?php include_once('includes/links.php'); ?>


  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Dashboard</h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><img src="<?php echo base_url();?>assets/dist/img/logo.png"/></span>

            <div class="info-box-content">
              <h1>Welcome to Auto Line Service</h1>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
		  
		
		  
		  
		  
        </div>
        
        <!-- /.col -->
      </div>
      
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
	
	
  </div>
  <!-- /.content-wrapper -->
  
  
<?php include_once('includes/footer.php'); ?>