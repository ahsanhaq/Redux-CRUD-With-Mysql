<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Update_form extends CI_Model {
	function __construct() 
	{
    	parent::__construct();
  		
	}
	
	public function update_form_val($data)
	
	{
	
	  
	
	}
	
	
	
}
?>	